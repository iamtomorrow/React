import React, { useState } from "react";

const UseStateObejct = () => {
  const [person, setPerson] = useState({
    name: "Karl",
    age: 45,
    message: "Hello"
  });
  // console.log(person);

  const [name, setName] = useState("Karl");
  const [age, setAge] = useState(45);
  const [message, setMessage] = useState("Karl");

  const changeMessage = () => {
    // setPerson({ ...person, message: "World" });
    let newMessage = prompt("New message: ");
    setMessage(newMessage);
  };

  const changeAge = () => {
    let newAge = prompt("New age: ");
    setAge(newAge);
  };

  return (
    <>
      <h3>{name}</h3>
      <h3>{age}</h3>
      <h3>{message}</h3>
      <button className="btn" type="button" onClick={changeMessage}>
        Change Message
      </button>
      <button className="btn" type="button" onClick={changeAge}>
        Change Age
      </button>
    </>
  );
};

export default UseStateObejct;
