import React, { useState } from "react";

const UseStateBasics = () => {
  const [count, setCount] = useState(0);
  const [text, setText] = useState("React");

  const Increment = () => {
    setCount(count + 1);
  };
  const Decrement = () => {
    setCount(count - 1);
  };

  const changeText = () => {
    let newText = window.prompt("New Text: ");
    setText(newText);
  };

  return (
    <React.Fragment>
      <h1> {count} </h1>
      <h1> {text} </h1>
      <button type="button" onClick={Increment}>
        Add
      </button>
      <button type="button" onClick={Decrement}>
        Dec
      </button>
      <button type="button" onClick={changeText}>
        Change Text
      </button>
    </React.Fragment>
  );
};

export default UseStateBasics;
