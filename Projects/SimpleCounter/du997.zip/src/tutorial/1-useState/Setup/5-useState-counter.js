import React, { useState } from "react";

const UseStateCounter = () => {
  const [value, setValue] = useState(0);

  const increment = () => {
    setValue(value + 1);
  };
  const decrement = () => {
    setValue(value - 1);
  };
  const reset = () => {
    setValue(0);
  };

  return (
    <div
      style={{
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center"
      }}
    >
      <section className="container">
        <h2>Regular Counter</h2>
        <h1 style={{ fontSize: "60px" }}>{value}</h1>
        <div className="btn_container">
          <button type="button" className="btn" onClick={increment}>
            Add
          </button>
          <button type="button" className="btn" onClick={reset}>
            Reset
          </button>
          <button type="button" className="btn" onClick={decrement}>
            Dec
          </button>
        </div>
      </section>
    </div>
  );
};

export default UseStateCounter;
