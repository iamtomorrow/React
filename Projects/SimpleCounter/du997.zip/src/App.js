import Setup from "./tutorial/1-useState/Setup/5-useState-counter";
import "./styles.css";

const App = () => {
  return (
    <div className="App">
      <Setup />
    </div>
  );
};

export default App;
